        <!-- Begin Page Content -->
        <div class="container-fluid pageSetting-page multi-lang-page" id = "all_menu_item" data-url ="<?= base_url('/')?>" >

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800"><?= $this->lang->line("Edit your main page")?></h1>
            <div class="row">

                <div class="col-md-12 ">
                    <?php
                    if($this->session->flashdata('msg')){
                        echo '<div class="alert alert-danger">'.$this->session->flashdata('msg').'</div>';
                    }
                    ?>
                    <div class="content_wrap tab-content">
                        <form action="<?=base_url('Restaurant/editMainPage')?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="rest_id" value = "<?= $myRestId?>">
                            <input type="hidden" name="what_setting" value = "homepage">
                           
                            <!-- modify by Jfrost in 2nd stage -->
                            <section>
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex justify-content-between title-bar">
                                        <div>
                                            <input type="checkbox" data-plugin="switchery" name = "is_show_service" data-color="#3DDCF7"   <?=$page_content && $page_content->is_show_service == 1 ? "checked" : "" ?>/>
                                            My Services (Click on the different buttons, to activate)
                                        </div>
                                        <div class="lang-bar">
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'english' ? 'active' : ''  ?> item-flag" data-flag="english"><img class="english-flag" src="<?= base_url('assets/flags/en-flag.png')?>"></span>
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'french' ? 'active' : ''  ?> item-flag" data-flag="french"><img class="french-flag" src="<?= base_url('assets/flags/fr-flag.png')?>"></span>
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'germany' ? 'active' : ''  ?> item-flag" data-flag="germany"><img class="germany-flag" src="<?= base_url('assets/flags/ge-flag.png')?>"></span>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row my-4">
                                            <div class="col-md-4 update-service_section_background">
                                                <?php
                                                 if ($page_content && $page_content->service_section_background !== ""){
                                                    $service_section_background = base_url("assets/home_service_background/").$page_content->service_section_background;
                                                }else{
                                                    $service_section_background = "";
                                                }
                                                ?>
                                                <input type="file" class="dropify" name="service_section_background" data-default-file = "<?= $service_section_background ?>" value = "<?= $service_section_background ?>"/>

                                                <input type="hidden" name="is_update_service_section_background" value = "<?= $service_section_background == "" ? "1" : "0"?>" />
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group row">
                                                    <label class="col-md-4 text-center"><?= $this->lang->line('Service Top Subject')?></label>
                                                    <div class="input-group french-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/fr-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_top_subject_french" placeholder="EXPÉRIENCE" value="<?= isset($page_content->service_top_subject_french) ? $page_content->service_top_subject_french : "" ?>">
                                                    </div>
                                                    <div class="input-group germany-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/ge-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_top_subject_germany" placeholder="ERFAHRUNG" value="<?=isset($page_content->service_top_subject_germany) ? $page_content->service_top_subject_germany:""?>">
                                                    </div>
                                                    <div class="input-group english-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/en-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_top_subject_english" placeholder="EXPERIENCE" value="<?=isset($page_content->service_top_subject_english) ? $page_content->service_top_subject_english:""?>">
                                                    </div>
                                                    
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-4 text-center"><?= $this->lang->line('Service Main Subject')?></label>
                                                    <div class="input-group french-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/fr-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_main_subject_french" placeholder="NOTRE SERVICE" value="<?=isset($page_content->service_main_subject_french) ? $page_content->service_main_subject_french:""?>">
                                                    </div>
                                                    <div class="input-group germany-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/ge-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_main_subject_germany" placeholder="UNSER SERVICE" value="<?=isset($page_content->service_main_subject_germany) ? $page_content->service_main_subject_germany:""?>">
                                                    </div>
                                                    <div class="input-group english-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/en-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_main_subject_english" placeholder="OUR SERVICE" value="<?=isset($page_content->service_main_subject_english) ? $page_content->service_main_subject_english:""?>">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-md-4 text-center"><?= $this->lang->line('Service Description')?></label>
                                                    <div class="input-group french-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/fr-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_description_french" placeholder="LOREM IPSUM DOLOR SIT AMET, CONSECTETUR ADIPISCING ELIT. ALIQUAM CONVALLIS ELEIFEND AUGUE, ID CONSEQUAT EX DICTUM AT." value="<?= isset($page_content->service_description_french) ?$page_content->service_description_french:"" ?>">
                                                    </div>
                                                    <div class="input-group germany-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/ge-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_description_germany" placeholder="LOREM IPSUM DOLOR SIT AMET, CONSECTETUR ADIPISCING ELIT. ALIQUAM CONVALLIS ELEIFEND AUGUE, ID CONSEQUAT EX DICTUM AT." value="<?=isset($page_content->service_description_germany) ?$page_content->service_description_germany : ""?>">
                                                    </div>
                                                    <div class="input-group english-field hide-field col-md-8 lang-field">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/en-flag.png')?>" ></span>
                                                        </div>
                                                        <input type="text" class="form-control" name="service_description_english" placeholder="LOREM IPSUM DOLOR SIT AMET, CONSECTETUR ADIPISCING ELIT. ALIQUAM CONVALLIS ELEIFEND AUGUE, ID CONSEQUAT EX DICTUM AT." value="<?= isset($page_content->service_description_english) ?$page_content->service_description_english:""?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <?php 
                                                if (sizeof($homepage_services) > 0){
                                                    $hs_index = 0;
                                                    foreach ($homepage_services as $hs_key => $hs_value) { 
                                                        $hs_index ++; ?>
                                                        <div class="col-md-2 mt-3">
                                                            <label class="<?=$hs_value->service_status == 1 ? "active" : "" ?> d-flex justify-content-center flex-column text-center homepage-services btn" alt="<?=$hs_value->service_alt?>">
                                                                <span class="active-signal badge badge-primary">ACTIVE</span>
                                                                <i class="fa frost-icon <?=$hs_value->service_alt ?> mb-2 mx-auto"><?= $hs_value->icon_svg?></i>
                                                                <p class="mb-0 text-capitalize"><?=$hs_value->service_name?></p>
                                                                <input type="checkbox" class="d-none" name="homepage_service_status[<?=$hs_value->id?>]" <?=$hs_value->service_status == 1 ? "checked" : "" ?>>
                                                                <input type="hidden" name="homepage_service_id[<?=$hs_value->id?>]" value="<?=$hs_value->hs_id?>">
                                                                <input type="hidden" name="service_id[<?=$hs_value->id?>]" value="<?=$hs_value->id?>">
                                                            </label>
                                                        </div>
                                                    <?php } 
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section>
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex justify-content-between title-bar">
                                        <input type="checkbox" data-plugin="switchery" name = "is_show_welcome" data-color="#3DDCF7"  <?= isset($page_content->is_show_welcome) && $page_content->is_show_welcome == 1 ? "checked" : "" ?>/>
                                        <div class="lang-bar">
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'english' ? 'active' : ''  ?> item-flag" data-flag="english"><img class="english-flag" src="<?= base_url('assets/flags/en-flag.png')?>"></span>
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'french' ? 'active' : ''  ?> item-flag" data-flag="french"><img class="french-flag" src="<?= base_url('assets/flags/fr-flag.png')?>"></span>
                                            <span class="<?= explode(",",$this->myRestDetail->website_languages)[0] == 'germany' ? 'active' : ''  ?> item-flag" data-flag="germany"><img class="germany-flag" src="<?= base_url('assets/flags/ge-flag.png')?>"></span>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <div class="col-md-4 update-image">
                                                <?php
                                                if (isset($page_content->content_image) && $page_content->content_image !== ""){
                                                    $content_image = base_url("assets/home_images/").$page_content->content_image;
                                                }else{
                                                    $content_image = "";
                                                }
                                                ?>
                                                <input type="file" class="dropify" name="content_img" data-slider-index="_content" data-default-file = "<?= $content_image ?>" value = "<?= $content_image ?>"/>

                                                <input type="hidden" name="is_update_content" value = "<?= $content_image == "" ? "1" : "0"?>" />
                                            </div>
                                            <div class="col-md-8">
                                                <div class="input-group english-field hide-field content-editor lang-field">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/en-flag.png')?>" ></span>
                                                    </div>
                                                    <textarea class="summernote form-control" name="page_content_english"  placeholder ="<?= $this->lang->line('Item Description')?>"><?= isset($page_content) ? $page_content->content_english : ""?></textarea>
                                                </div>
                                                <div class="input-group french-field hide-field content-editor lang-field">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/fr-flag.png')?>" ></span>
                                                    </div>
                                                    <textarea class="summernote form-control" name="page_content_french"  placeholder ="<?= $this->lang->line('Item Description')?>" ><?= isset($page_content) ? $page_content->content_french : "" ?></textarea>
                                                </div>
                                                <div class="input-group germany-field hide-field content-editor lang-field">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><img class="img-profile rounded-circle active-flag" src="<?= base_url('assets/flags/ge-flag.png')?>" ></span>
                                                    </div>
                                                    <textarea class="summernote form-control" name="page_content_germany" placeholder ="<?= $this->lang->line('Item Description')?>" ><?= isset($page_content) ? $page_content->content_germany : ""?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-12 mx-auto mb-3 mb-sm-0">
                                                <input type="submit" name="" value="<?= $this->lang->line('SAVE')?>" class="btn btn-danger btn-user btn-block submit-btn">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </form>
                    </div>
                </div>
            
            </div>
        </div>
        <!-- /.container-fluid -->

        
<script type="text/javascript">

$(document).on('click','.update-service_section_background .dropify-clear',function(){
    $("input[name='is_update_service_section_background']").val("1");
});
$(document).on('click','.update-image .dropify-clear',function(){
    $("input[name='is_update_content']").val("1");
});
</script>
